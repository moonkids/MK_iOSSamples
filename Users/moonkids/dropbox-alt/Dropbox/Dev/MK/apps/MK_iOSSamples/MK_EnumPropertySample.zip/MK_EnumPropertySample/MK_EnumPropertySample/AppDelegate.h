//
//  AppDelegate.h
//  MK_EnumPropertySample
//
//  Created by MurataKazuki on 2013/10/27.
//  Copyright (c) 2013年 MK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
