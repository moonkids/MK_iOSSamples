//
//  ImageData.h
//  MK_CoreDataSchoolMember
//
//  Created by MurataKazuki on 2013/12/17.
//  Copyright (c) 2013年 MK. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface ImageData : NSManagedObject

@property (nonatomic, retain) NSData * data;

@end
