//
//  Student.m
//  MK_CoreDataSchoolMember
//
//  Created by MurataKazuki on 2013/12/17.
//  Copyright (c) 2013年 MK. All rights reserved.
//

#import "Student.h"
#import "ImageData.h"


@implementation Student

@dynamic id;
@dynamic name;
@dynamic sex;
@dynamic birthday;
@dynamic imageData;

@end
