//
//  ViewController.m
//  MK_SizeFitSample
//
//  Created by MurataKazuki on 2013/11/11.
//  Copyright (c) 2013年 MK. All rights reserved.
//

#import "ViewController.h"
#import "UIViewCustomizedForSizeThatFits2.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    

    //サイズが小さい場合
//    UIViewCustomizedForSizeThatFits2 *parentView = [[UIViewCustomizedForSizeThatFits2 alloc] initWithFrame:CGRectMake(10, 100, 150, 200)];

    //サイズが大きい場合
    UIViewCustomizedForSizeThatFits2 *parentView = [[UIViewCustomizedForSizeThatFits2 alloc] initWithFrame:CGRectMake(10, 100, 300, 350)];
    parentView.backgroundColor = [UIColor blueColor];
    [self.view addSubview:parentView];
    
    UIView *subView1 = [[UIView alloc] initWithFrame:CGRectMake(10, 100, 200, 200)];
    subView1.backgroundColor = [UIColor redColor];
    [parentView addSubview:subView1];

    UIView *subView2 = [[UIView alloc] initWithFrame:CGRectMake(100, 50, 150, 100)];
    subView2.backgroundColor = [UIColor yellowColor];
    [parentView addSubview:subView2];

//    [parentView sizeToFit];
//    [parentView sizeToFitWithWidthFixed:NO isHeightFixed:NO];
    [parentView sizeToFitWithWidthFixed:NO isHeightFixed:NO];
//    [parentView sizeToFitWithWidthFixed:NO isHeightFixed:YES];
//    [parentView sizeToFitWithWidthFixed:YES isHeightFixed:NO];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
