//
//  List2ViewController.h
//  MK_EditableTableSample
//
//  Created by MurataKazuki on 2013/10/08.
//  Copyright (c) 2013年 MK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface List2ViewController : UITableViewController

@end
