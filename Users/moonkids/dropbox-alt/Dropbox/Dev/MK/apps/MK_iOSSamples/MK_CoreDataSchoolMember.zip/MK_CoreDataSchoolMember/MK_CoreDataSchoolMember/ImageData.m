//
//  ImageData.m
//  MK_CoreDataSchoolMember
//
//  Created by MurataKazuki on 2013/12/17.
//  Copyright (c) 2013年 MK. All rights reserved.
//

#import "ImageData.h"


@implementation ImageData

@dynamic data;

@end
