//
//  AppDelegate.h
//  MK_ImageResize
//
//  Created by MurataKazuki on 2014/02/06.
//  Copyright (c) 2014年 MK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
