//
//  Classroom.m
//  MK_CoreDataSchoolMember
//
//  Created by MurataKazuki on 2013/12/17.
//  Copyright (c) 2013年 MK. All rights reserved.
//

#import "Classroom.h"
#import "Student.h"


@implementation Classroom

@dynamic createDate;
@dynamic grade;
@dynamic name;
@dynamic students;

@end
