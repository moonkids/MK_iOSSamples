//
//  AppDelegate.h
//  MK_ViewExcendsSample
//
//  Created by MurataKazuki on 2013/11/12.
//  Copyright (c) 2013年 MK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
