//
//  UIViewCustomizedForSizeThatFits.h
//  Life Timer2
//
//  Created by Hayato on 13/10/29.
//  Copyright (c) 2013年 Crazyonez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewCustomizedForSizeThatFits2 : UIView

- (void)sizeToFitWithWidthFixed:(BOOL)isWidthFixed isHeightFixed:(BOOL)isHeightFixed;
- (CGSize)sizeThatFits:(CGSize)size isWidthFixed:(BOOL)isWidthFixed isHeightFixed:(BOOL)isHeightFixed;

@end
