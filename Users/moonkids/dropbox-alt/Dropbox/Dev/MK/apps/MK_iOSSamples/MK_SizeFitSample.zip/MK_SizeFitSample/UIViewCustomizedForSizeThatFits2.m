//
//  UIViewCustomizedForSizeThatFits.m
//  Life Timer2
//
//  Created by Hayato on 13/10/29.
//  Copyright (c) 2013年 Crazyonez. All rights reserved.
//

#import "UIViewCustomizedForSizeThatFits2.h"

@interface UIViewCustomizedForSizeThatFits2(){
    BOOL _isWidthFixed;
    BOOL _isHeightFixed;
}
@end

@implementation UIViewCustomizedForSizeThatFits2

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(void)sizeToFit{
    NSLog(@"sizeToFit");
    [super sizeToFit]; //サイズ調節！！！！
}

- (void)sizeToFitWithWidthFixed:(BOOL)isWidthFixed isHeightFixed:(BOOL)isHeightFixed
{
    _isWidthFixed = isWidthFixed;
    _isHeightFixed = isHeightFixed;
    [self sizeToFit];
}


- (CGSize)sizeThatFits:(CGSize)size
{
    
    NSMutableArray *widthArray = [@[] mutableCopy];
    NSMutableArray *heightArray = [@[] mutableCopy];
    
    
    for (UIView* subview in self.subviews) {
        
        NSNumber *width = [[NSNumber alloc] initWithInt:(subview.frame.origin.x + subview.frame.size.width)];
        [widthArray addObject:width];
        
        NSNumber *height = [[NSNumber alloc] initWithInt:(subview.frame.origin.y + subview.frame.size.height)];
        [heightArray addObject:height];
        
    }
    
    
    float newWidth = [[widthArray valueForKeyPath:@"@max.self"] floatValue];
    float newHeight = [[heightArray valueForKeyPath:@"@max.self"] floatValue];

    //もともとのサイズより小さくしない
    if (_isWidthFixed) {
        newWidth = (newWidth < self.frame.size.width)?self.frame.size.width:newWidth;
    }
    if (_isHeightFixed) {
        newHeight = (newHeight < self.frame.size.height)?self.frame.size.height:newHeight;
    }
    
    CGSize modifiedSize = CGSizeMake(newWidth, newHeight);
    
    NSLog(@"sizeThatFits:%@がリターンされる", NSStringFromCGSize(modifiedSize));
    
    return modifiedSize;
}





/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
