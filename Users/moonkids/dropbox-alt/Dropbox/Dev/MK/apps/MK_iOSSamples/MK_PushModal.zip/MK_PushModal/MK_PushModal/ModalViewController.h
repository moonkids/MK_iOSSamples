//
//  ModalViewController.h
//  MK_PushModal
//
//  Created by MurataKazuki on 2014/02/13.
//  Copyright (c) 2014年 MK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModalViewController : UIViewController

@end
