//
//  PersonsViewController.h
//  MK_ContentViewSample
//
//  Created by MurataKazuki on 2013/11/17.
//  Copyright (c) 2013年 MK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PeopleTableViewController : UITableViewController

@end
