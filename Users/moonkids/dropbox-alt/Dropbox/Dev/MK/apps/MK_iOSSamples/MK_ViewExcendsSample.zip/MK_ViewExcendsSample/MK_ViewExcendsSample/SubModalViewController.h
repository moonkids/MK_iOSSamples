//
//  SubModalViewController.h
//  MK_ViewExcendsSample
//
//  Created by MurataKazuki on 2013/11/12.
//  Copyright (c) 2013年 MK. All rights reserved.
//

#import "SuperModalViewController.h"

@interface SubModalViewController : SuperModalViewController

@end
