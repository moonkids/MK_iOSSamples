//
//  PersonsViewController.m
//  MK_ContentViewSample
//
//  Created by MurataKazuki on 2013/11/17.
//  Copyright (c) 2013年 MK. All rights reserved.
//

#import "PeopleTableViewController.h"

@implementation PeopleTableViewController

@end
